# Darwin Pricing Integration for WooCommerce
WordPress plugin: Provides the integration between [Darwin Pricing](https://www.darwinpricing.com) and [WooCommerce](http://www.woothemes.com/woocommerce/).
Requires WooCommerce 2.1.
